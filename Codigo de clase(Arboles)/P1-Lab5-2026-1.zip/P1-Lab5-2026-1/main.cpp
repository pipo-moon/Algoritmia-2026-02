#include <iostream>
#define N 20
#include "BibliotecaArbolBinarioBusqueda/ArbolBinarioBusqueda.h"
#include "BibliotecaArbolBinarioBusqueda/funcionesArbolBinarioBusqueda.h"
#include "BibliotecaPila/Pila.h"
#include "BibliotecaPila/funcionesPila.h"

using namespace std;

void pasaPila(Pila &pilaOrigen,Pila &pilaDestino)
{
    int n;
    ElementoPila ultimoElemento;
    while (!esPilaVacia(pilaOrigen))
    {
        ultimoElemento = desapilar(pilaOrigen);
        n=0;
        while (!esPilaVacia(pilaOrigen))
        {
            apilar(pilaDestino, ultimoElemento);
            n++;
            ultimoElemento = desapilar(pilaOrigen);
        }
        /*Ahora los regreso*/
        while (n>0)
        {
            apilar(pilaOrigen,desapilar(pilaDestino));
            n--;
        }
        apilar(pilaDestino,ultimoElemento);
    }
}

void ZigZagOrder(ArbolBinarioBusqueda &arbol)
{
    int nivel=1;
    bool izquierdaDerecha = true;
    Pila pilaActual;
    Pila pilaSiguiente;
    construir(pilaActual);
    construir(pilaSiguiente);
    ElementoPila elementoPila, elementoPilaSiguiente;
    elementoPila.elemento = arbol.raiz;
    apilar(pilaActual,elementoPila);
    while (!esPilaVacia(pilaActual))
    {
        cout << "Nivel : " << nivel << endl;
        izquierdaDerecha = !izquierdaDerecha;
        while (!esPilaVacia(pilaActual))
        {
            elementoPila = desapilar(pilaActual);
            cout << elementoPila.elemento->elemento.numero << " " << endl;
            if (!izquierdaDerecha)
            {
                if (elementoPila.elemento->izquierda!=NULL)
                {
                    elementoPilaSiguiente.elemento = elementoPila.elemento->izquierda;
                    apilar(pilaSiguiente,elementoPilaSiguiente);
                }
                if (elementoPila.elemento->derecha!=NULL)
                {
                    elementoPilaSiguiente.elemento = elementoPila.elemento->derecha;
                    apilar(pilaSiguiente,elementoPilaSiguiente);
                }
            }
            else
            {
                if (elementoPila.elemento->derecha!=NULL)
                {
                    elementoPilaSiguiente.elemento = elementoPila.elemento->derecha;
                    apilar(pilaSiguiente,elementoPilaSiguiente);
                }
                if (elementoPila.elemento->izquierda!=NULL)
                {
                    elementoPilaSiguiente.elemento = elementoPila.elemento->izquierda;
                    apilar(pilaSiguiente,elementoPilaSiguiente);
                }
            }
        }
        nivel++;
        pasaPila(pilaSiguiente,pilaActual);
    }
}

int main()
{
    ArbolBinarioBusqueda arbol;
    construir(arbol);
    int arreglo[N] = {9,4,14,1,6,11,16,19};
    int n=8;
    ElementoArbolBinarioBusqueda elemento;
    for (int i=0; i<n; i++)
    {
        elemento.numero = arreglo[i];
        insertar(arbol,elemento);
    }
    ZigZagOrder(arbol);
    return 0;
}
