cmake_minimum_required(VERSION 4.0)
project(ArbolCromosomatico)

set(CMAKE_CXX_STANDARD 20)

add_executable(ArbolCromosomatico main.cpp
        BibliotecaArbolBinario/funcionesArbolBinario.cpp)
