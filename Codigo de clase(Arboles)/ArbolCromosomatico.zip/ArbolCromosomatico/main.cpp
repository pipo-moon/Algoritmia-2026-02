#include <iostream>
#define N 10

#include "BibliotecaArbolBinario/ArbolBinario.h"
#include "BibliotecaArbolBinario/funcionesArbolBinario.h"
using namespace std;

void agregarElementoCromosomaRecursivo(NodoArbolBinario *&nodo,int valor,int bit)
{
    if (nodo != NULL)
    {
        agregarElementoCromosomaRecursivo(nodo->izquierda,valor,0);
        agregarElementoCromosomaRecursivo(nodo->derecha,valor,1);
    }
    else
    {
        /*Caso Base*/
        ElementoArbolBinario elemento;
        elemento.bit = bit;
        elemento.numero = valor;
        plantarNodoArbolBinario(nodo,NULL,elemento,NULL);
    }
}

void agregarElementoCromosoma(ArbolBinario &arbol,int valor)
{
    agregarElementoCromosomaRecursivo(arbol.raiz,valor,0);
}

int calcularCombinacionesRecursivo(NodoArbolBinario *nodo,int peso,int suma)
{
    if (nodo->izquierda==NULL && nodo->derecha==NULL)
    {
        suma = suma + nodo->elemento.bit*nodo->elemento.numero;
        if (suma==peso)
        {
            return 1;
        }
        return 0;
    }
    suma = suma + nodo->elemento.bit*nodo->elemento.numero;
    return calcularCombinacionesRecursivo(nodo->izquierda,peso,suma) + calcularCombinacionesRecursivo(nodo->derecha,peso,suma);
}

int calcularCombinaciones(const ArbolBinario &arbol,int peso)
{
    return calcularCombinacionesRecursivo(arbol.raiz,peso,0);
}

int main()
{
    int arreglo[N] = {10,50,20,30,40};
    int n=5;
    /*Parte a*/
    ArbolBinario arbol;
    construir(arbol);
    ElementoArbolBinario elemento;
    elemento.numero = 0;
    elemento.bit = 0;
    plantarNodoArbolBinario(arbol.raiz,NULL,elemento,NULL);
    for (int i=0; i<n; i++)
    {
        agregarElementoCromosoma(arbol,arreglo[i]);
    }
    /*recorrerPreOrden(arbol);*/
    int peso = 70;
    cout << calcularCombinaciones(arbol,peso) << endl;
    return 0;
}
