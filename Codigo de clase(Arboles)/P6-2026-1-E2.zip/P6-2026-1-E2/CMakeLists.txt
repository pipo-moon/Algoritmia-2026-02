cmake_minimum_required(VERSION 4.0)
project(P6_2026_1_E2)

set(CMAKE_CXX_STANDARD 20)

add_executable(P6_2026_1_E2 main.cpp
        BibliotecaArbolBinarioBusqueda/ArbolBinarioBusqueda.h
        BibliotecaCola/funcionesCola.cpp)
