#include <iostream>

#include "BibliotecaArbolBinarioBusqueda/ArbolBinarioBusqueda.h"
#include "BibliotecaCola/Cola.h"
#include "BibliotecaCola/funcionesCola.h"
#define N 20
using namespace std;

void construir(ArbolBinarioBusqueda &arbol)
{
    arbol.raiz = NULL;
}

void insertarIterativo(NodoArbolBinarioBusqueda *&nodo, ElementoArbolBinarioBusqueda elemento)
{
    /*Creo el nodo que voy a insertar*/
    NodoArbolBinarioBusqueda *nuevo = new NodoArbolBinarioBusqueda;
    nuevo->elemento = elemento;
    nuevo->derecha = NULL;
    nuevo->izquierda= NULL;
    /*Este caso solo se aplica para la raiz*/
    if (nodo==NULL)
    {
        nodo = nuevo;
        //cout << "Inserto elemento" << endl;
        return ;
    }
    NodoArbolBinarioBusqueda *actual = nodo;
    NodoArbolBinarioBusqueda *padre = NULL;
    while (actual != NULL)
    {
        padre = actual;
        if (actual->elemento.valor > elemento.valor)
        {
            actual = actual->izquierda;
        }
        else
        {
            if (actual->elemento.valor < elemento.valor)
            {
                actual = actual->derecha;
            }
            else
            {
                return ;
            }
        }
    }
    if (nodo->elemento.valor > elemento.valor)
    {
        padre->izquierda = nuevo;
    }
    else
    {
        padre->derecha = nuevo;
    }
    //cout << "Inserto elemento" << endl;
}

void reconstruirABB(ArbolBinarioBusqueda &arbol,int arreglo[N],int n)
{
    ElementoArbolBinarioBusqueda elemento;
    for (int i=0; i<n; i++)
    {
        elemento.valor = arreglo[i];
        insertarIterativo(arbol.raiz, elemento);
    }
}

NodoArbolBinarioBusqueda * buscarIterativo(NodoArbolBinarioBusqueda *nodo, int valor)
{
    NodoArbolBinarioBusqueda *actual = nodo;
    while (actual != NULL)
    {
        if (actual->elemento.valor == valor)
        {
            return actual;
        }
        else
        {
            if (actual->elemento.valor < valor)
            {
                actual = actual->derecha;
            }
            else
            {
                actual = actual->izquierda;
            }
        }
    }
    return actual;
}

void imprimirAmplitud(const ArbolBinarioBusqueda &arbol)
{
    Cola cola;
    construir(cola);
    ElementoCola elementoCola;
    elementoCola.codigo = arbol.raiz->elemento.valor;
    encolar(cola,elementoCola);
    while (!esColaVacia(cola))
    {
        elementoCola = desencolar(cola);
        cout << elementoCola.codigo << " ";
        NodoArbolBinarioBusqueda *nodo = buscarIterativo(arbol.raiz, elementoCola.codigo);
        if (nodo->izquierda!=NULL)
        {
            elementoCola.codigo = nodo->izquierda->elemento.valor;
            encolar(cola,elementoCola);
        }
        if (nodo->derecha!=NULL)
        {
            elementoCola.codigo = nodo->derecha->elemento.valor;
            encolar(cola,elementoCola);
        }
    }
}

int main()
{
    ArbolBinarioBusqueda arbol;
    construir(arbol);
    int arreglo[N] = {50,30,70,20,60};
    int n = 5;
    //cout << arbol.raiz;
    reconstruirABB(arbol,arreglo,n);
    //cout << arbol.raiz;
    imprimirAmplitud(arbol);
    return 0;
}