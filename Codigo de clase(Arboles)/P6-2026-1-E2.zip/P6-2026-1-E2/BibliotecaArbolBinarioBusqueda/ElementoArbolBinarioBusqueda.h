//Fecha:  jueves 30 Octubre 2025 
//Autor: Ana Roncal 
#include <cstring>
using namespace std;

#ifndef ARBOLBINARIOBUSQUEDA_ELEMENTOARBOLBINARIOBUSQUEDA_H
#define ARBOLBINARIOBUSQUEDA_ELEMENTOARBOLBINARIOBUSQUEDA_H
struct ElementoArbolBinarioBusqueda {
    int valor;
};
#endif //ARBOLBINARIOBUSQUEDA_ELEMENTOARBOLBINARIOBUSQUEDA_H